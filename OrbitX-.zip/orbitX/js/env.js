// LOCAL CONFIG - this file is git-ignored. Do not commit it.
// Copy of env.example.js with your real Supabase project values.
window.ORBIT_ENV = {
    SUPABASE_URL: "https://dhtbiggamuwoqurguhib.supabase.co",
    SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRodGJpZ2dhbXV3b3F1cmd1aGliIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMxNzY2MzksImV4cCI6MjA3ODc1MjYzOX0.-utin9W_-hSeijdHwcVSjft9biB5DSXrNOmuz5kCPlE"
};

// Copy this file to js/env.js and fill in your own Supabase project values.
// js/env.js is git-ignored so your project details are not committed.
// Use ONLY the public "anon" / publishable key here - never the service_role key.
window.ORBIT_ENV = {
    SUPABASE_URL: "https://YOUR-PROJECT-REF.supabase.co",
    SUPABASE_ANON_KEY: "YOUR-SUPABASE-ANON-KEY"
};

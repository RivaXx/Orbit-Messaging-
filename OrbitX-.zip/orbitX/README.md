# Orbit Messenger

A browser-based (PWA) messenger built with vanilla JS and [Supabase](https://supabase.com) (auth, database, realtime, storage).

## Setup

1. Create a Supabase project.
2. In the Supabase SQL Editor, run the files in `docs/sql/` (see the order below). **Make sure Row Level Security (RLS) is enabled on every table** (messages, rooms, error_logs, profiles, ...).
3. Copy the config template and fill in your project values:
   ```
   cp js/env.example.js js/env.js
   ```
   Use only the public **anon / publishable** key. Never put the `service_role` key anywhere in this project.
4. Run locally:
   - Windows: double-click `Start-Orbit.cmd` (needs Node.js)
   - Any OS: `node serve.cjs`, then open http://127.0.0.1:4173/

## SQL files (`docs/sql/`)
- `FIX_ORBIT_MEDIA.sql` - creates the `chat-assets` storage bucket and upload policies
- `FIX_MEDIA_UPLOAD_POLICIES.sql` - restricts uploads to each user's own folder
- `FIX_ORBIT_DELIVERY.sql` - realtime/broadcast and attachment-read policies

## Security notes
- `js/env.js` is git-ignored. The anon key is public by design (it ships to every browser), so your **RLS policies are what actually protect your data**.
- The `chat-assets` bucket is public by default in the provided SQL: anyone with a file URL can open it. Make it private if you need stricter privacy.

## Deploying (GitHub Pages, Netlify, etc.)
`js/env.js` is not in the repo, so the host must create it at deploy time (e.g. from CI secrets/variables), or you can commit it deliberately if you accept the anon key being public.

## Third-party
Bundled libraries live in `assets/vendor/` with their licenses (supabase-js, tus-js-client; both MIT).
